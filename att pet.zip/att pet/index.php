<!DOCTYPE html>
<html lang="pt-br">
    <head>
        <meta charset="utf-8" />
        <title>Revisão 02/05/2022</title>
    </head>
    <body>
        <h1>Idade do Pet</h1>
        Selecione o seu pet<br>
        <form name="form1" method="post" action="calculo.php">
        <select name="tipo">
            <option value="cao" >Cachorro</option>
            <option value="gato">Gato</option>
        </select><br>
        <label>Idade em "anos"<br>
        <input type="text" size=15 maxlength="2" name="idade" /></label><br>
        <input type="submit" value="Enviar" name="calcular" />
        <input type="reset" value="Limpar" name="limpar" />
        </form>

    </body>
</html>