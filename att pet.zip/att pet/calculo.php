<?php
$tipo = $_POST['tipo'];
$idade = $_POST['idade'];
$idadepet = 0;

if( $tipo == "cao"){

    $idadepet = $idade * 7;
    echo "A idade do seu cachorro e " .$idadepet;
}

if ($tipo == "gato"){

    $idadepet = $idade * 4;
    echo "A idade do seu gato e " .$idadepet;
}